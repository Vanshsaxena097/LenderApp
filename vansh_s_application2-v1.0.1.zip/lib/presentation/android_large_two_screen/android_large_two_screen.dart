import 'package:flutter/material.dart';
import '../../core/app_export.dart';
import '../../theme/custom_button_style.dart';
import '../../widgets/custom_elevated_button.dart';
import '../../widgets/custom_text_form_field.dart'; // ignore_for_file: must_be_immutable

// ignore_for_file: must_be_immutable
class AndroidLargeTwoScreen extends StatelessWidget {
  AndroidLargeTwoScreen({Key? key})
      : super(
          key: key,
        );

  TextEditingController passwordController = TextEditingController();

  GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        body: SizedBox(
          width: SizeUtils.width,
          child: SingleChildScrollView(
            padding: EdgeInsets.only(
              bottom: MediaQuery.of(context).viewInsets.bottom,
            ),
            child: SizedBox(
              height: SizeUtils.height,
              child: Form(
                key: _formKey,
                child: SizedBox(
                  height: SizeUtils.height,
                  width: double.maxFinite,
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      Align(
                        alignment: Alignment.center,
                        child: Container(
                          padding: EdgeInsets.symmetric(
                            horizontal: 43.h,
                            vertical: 212.v,
                          ),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              Spacer(),
                              CustomElevatedButton(
                                text: "Username",
                                buttonStyle: CustomButtonStyles.fillYellowTL18,
                                buttonTextStyle:
                                    CustomTextStyles.titleLargeInter,
                              ),
                              SizedBox(height: 81.v),
                              CustomTextFormField(
                                controller: passwordController,
                                hintText: "Password",
                                hintStyle: CustomTextStyles.titleLargeInter,
                                textInputAction: TextInputAction.done,
                                textInputType: TextInputType.visiblePassword,
                                obscureText: true,
                                contentPadding: EdgeInsets.symmetric(
                                  horizontal: 30.h,
                                  vertical: 6.v,
                                ),
                                borderDecoration:
                                    TextFormFieldStyleHelper.fillYellowTL18,
                                fillColor: appTheme.yellow100,
                              ),
                              SizedBox(height: 76.v),
                              CustomElevatedButton(
                                text: "Login",
                                margin: EdgeInsets.only(
                                  left: 24.h,
                                  right: 26.h,
                                ),
                                buttonStyle: CustomButtonStyles.fillYellowTL181,
                                buttonTextStyle:
                                    CustomTextStyles.titleLargeInter,
                              )
                            ],
                          ),
                        ),
                      ),
                      CustomImageView(
                        imagePath: ImageConstant.imgImage6,
                        height: 800.v,
                        width: 360.h,
                        radius: BorderRadius.circular(
                          30.h,
                        ),
                        alignment: Alignment.center,
                      )
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
