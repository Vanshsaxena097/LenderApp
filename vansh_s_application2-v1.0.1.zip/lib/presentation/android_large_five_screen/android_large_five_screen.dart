import 'package:flutter/material.dart';
import '../../core/app_export.dart';
import 'widgets/availablegrid_item_widget.dart';

class AndroidLargeFiveScreen extends StatelessWidget {
  const AndroidLargeFiveScreen({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: SizedBox(
          width: double.maxFinite,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              _buildDashboardRow(context),
              Padding(
                padding: EdgeInsets.only(right: 11.h),
                child: Text(
                  "Lets Lend It !",
                  style: CustomTextStyles.headlineLargeInterYellow100,
                ),
              ),
              SizedBox(height: 2.v),
              _buildAvailableGrid(context)
            ],
          ),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildDashboardRow(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(right: 1.h),
      padding: EdgeInsets.symmetric(
        horizontal: 4.h,
        vertical: 22.v,
      ),
      decoration: AppDecoration.fillYellow.copyWith(
        borderRadius: BorderRadiusStyle.roundedBorder50,
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Padding(
            padding: EdgeInsets.only(
              top: 14.v,
              bottom: 11.v,
            ),
            child: Text(
              "Dashboard",
              style: theme.textTheme.displaySmall,
            ),
          ),
          CustomImageView(
            imagePath: ImageConstant.imgLogoSearchGrid1x,
            height: 68.v,
            width: 105.h,
            margin: EdgeInsets.only(
              top: 2.v,
              right: 29.h,
            ),
          )
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildAvailableGrid(BuildContext context) {
    return GridView.builder(
      shrinkWrap: true,
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        mainAxisExtent: 174.v,
        crossAxisCount: 2,
        mainAxisSpacing: 1.h,
        crossAxisSpacing: 1.h,
      ),
      physics: NeverScrollableScrollPhysics(),
      itemCount: 10,
      itemBuilder: (context, index) {
        return AvailablegridItemWidget();
      },
    );
  }
}
