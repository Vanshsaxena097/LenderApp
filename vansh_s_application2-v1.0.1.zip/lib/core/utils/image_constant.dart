// ignore_for_file: must_be_immutable
class ImageConstant {
  // Image folder path
  static String imagePath = 'assets/images';

// login images
  static String imgVector = '$imagePath/img_vector.svg';

  static String imgBxbxhide = '$imagePath/img_bxbxhide.svg';

  static String imgFlatColorIconsGoogle =
      '$imagePath/img_flat_color_icons_google.svg';

  static String imgCiApple = '$imagePath/img_ci_apple.svg';

// Android Large - Two images
  static String imgImage6 = '$imagePath/img_image_6.png';

// Android Large - Eight images
  static String imgDownload19 = '$imagePath/img_download_19.png';

  static String imgDownload18 = '$imagePath/img_download_18.png';

// Android Large - Five images
  static String imgLogoSearchGrid1x = '$imagePath/img_logo_search_grid_1x.png';

  static String imgImages3 = '$imagePath/img_images_3.png';

  static String imgImages4 = '$imagePath/img_images_4.png';

  static String imgImages2 = '$imagePath/img_images_2.png';

  static String imgDownload11 = '$imagePath/img_download_11.png';

  static String imgDownload15 = '$imagePath/img_download_15.png';

  static String imgDownload12 = '$imagePath/img_download_12.png';

  static String imgImages456x64 = '$imagePath/img_images_4_56x64.png';

  static String imgDownload1556x74 = '$imagePath/img_download_15_56x74.png';

  static String imgDownload13 = '$imagePath/img_download_13.png';

// Common images
  static String imgDownload22 = '$imagePath/img_download_22.png';

  static String imgDownload2237x47 = '$imagePath/img_download_22_37x47.png';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
